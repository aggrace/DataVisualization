### UI
library(shiny)

weather <- read.csv("data/weather.csv")


pageWithSidebar(
  headerPanel('Weather k-means clustering'),
  sidebarPanel(
    selectInput('xcol', 'X Variable', names(weather)),
    selectInput('ycol', 'Y Variable', names(weather),
                selected=names(weather)[[2]]),
    numericInput('clusters', 'Cluster count', 7,
                 min = 1, max = 9)
  ),
  mainPanel(
    plotOutput('plot1')
  )
)